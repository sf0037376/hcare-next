(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_0c5c888c._.js",
  "static/chunks/_9cc5731d._.js",
  "static/chunks/app_globals_71f961d1.css"
],
    source: "dynamic"
});
